export default function Hero() {
  return (
    <section id="inicio" className="hero">
      <div className="hero-copy">
        <p className="eyebrow"><i /> JLScript 3.2.0 · linguagem brasileira · em evolução</p>
        <h1>JL<span>Script</span></h1>
        <h2>Programação em português e inglês, com runtime e ferramentas próprias.</h2>
        <p className="hero-description">
          Uma linguagem criada no Brasil para unir sintaxe direta, CLI integrada,
          bibliotecas oficiais, build nativo e bytecode sem transformar o primeiro
          contato com programação em um ritual burocrático.
        </p>
        <div className="buttons">
          <a className="btn" href="#/docs">Começar agora <b>→</b></a>
          <a className="btn-outline" href="#/docs">Documentação</a>
          <a className="text-link" href="#/download">Download ↓</a>
        </div>
      </div>

      <div className="hero-terminal" aria-label="Exemplo de API em JLScript">
        <div className="terminal-top">
          <span className="terminal-dots" aria-hidden="true"><i /><i /><i /></span>
          <small>api.jls</small><em>JLScript 3.2.0</em>
        </div>
        <pre><code>
          <span className="tok-keyword">import</span> <span className="tok-lib">#api</span>{"\n\n"}
          <span className="tok-keyword">va</span> app <span className="tok-op">=</span> api.<span className="tok-function">server</span>({"{"}{"\n  "}host: <span className="tok-string">"127.0.0.1"</span>,{"\n  "}port: <span className="tok-number">3000</span>{"\n"}{"}"}){"\n\n"}
          app.<span className="tok-function">get</span>(<span className="tok-string">"/"</span>, <span className="tok-keyword">func</span>(req, res) {"{"}{"\n  "}res.<span className="tok-function">json</span>({"{"}status: <span className="tok-string">"online"</span>{"}"}){"\n"}{"}"}){"\n\n"}
          app.<span className="tok-function">listen</span>()
        </code></pre>
        <div className="terminal-result">✓ servidor pronto em 127.0.0.1:3000</div>
      </div>
    </section>
  );
}
