const itens = [
  ["PT/EN", "Português + inglês", "Condições, laços e outras estruturas com formas bilíngues suportadas pelo parser."],
  [">_", "CLI integrada", "Execute, teste, formate, diagnostique, compile e mantenha projetos com o comando jls."],
  ["01", "Build + bytecode", "Interprete código .jls, gere executável nativo ou compile para bytecode .jlb."],
  ["#", "Bibliotecas oficiais", "API, JSON, arquivos, banco, rede, criptografia, processos, imagem, áudio e outros módulos."],
];

export default function Features() {
  return (
    <section className="section">
      <header className="section-heading">
        <p>POR QUE JLSCRIPT</p>
        <h2>Mais que sintaxe bonita.</h2>
        <span>A versão 3.2.0 já reúne linguagem, runtime, compilação, ferramentas e bibliotecas em um ecossistema próprio.</span>
      </header>
      <div className="features">
        {itens.map(([icon, titulo, texto]) => (
          <article className="feature-card card" key={titulo}>
            <span className="feature-icon">{icon}</span><h3>{titulo}</h3><p>{texto}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
