import { useState } from "react";

const codigo = `mostrar("Olá Mundo")

va nome = "Lucas"

func saudacao(nome) {
    mostrar("Olá " + nome)
}

saudacao(nome)`;

export default function CodePreview() {
  const [copiado, setCopiado] = useState(false);

  const copiar = async () => {
    await navigator.clipboard?.writeText(codigo);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 1800);
  };

  return (
    <section className="section code-section">
      <div>
        <p className="eyebrow">SIMPLES POR DESIGN</p>
        <h2>
          Escreva menos.
          <br />
          <span>Faça mais.</span>
        </h2>
        <p>
          Uma sintaxe próxima da sua forma de pensar. Menos cerimônia, mais espaço para criar.
        </p>
        <button className="copy-button" onClick={copiar}>
          {copiado ? "✓ Código copiado" : "⧉ Copiar código"}
        </button>
      </div>

      <div className="code-window dracula-window">
        <div className="code-window-head">
          <span className="terminal-dots" aria-hidden="true">
            <i />
            <i />
            <i />
          </span>
          <b>exemplo.jls</b>
          <small>● Pronto</small>
        </div>
        <pre>
          <code>
            <span className="tok-function">mostrar</span>(<span className="tok-string">"Olá Mundo"</span>)
            {"\n\n"}
            <span className="tok-keyword">va</span> nome <span className="tok-op">=</span>{" "}
            <span className="tok-string">"Lucas"</span>
            {"\n\n"}
            <span className="tok-keyword">func</span> <span className="tok-function">saudacao</span>(nome) {"{"}
            {"\n    "}<span className="tok-function">mostrar</span>(
            <span className="tok-string">"Olá "</span> <span className="tok-op">+</span> nome)
            {"\n"}{"}"}
            {"\n\n"}
            <span className="tok-function">saudacao</span>(nome)
          </code>
        </pre>
      </div>
    </section>
  );
}
