import { useState } from "react";
import GlobalSearch from "./GlobalSearch";

const primaryLinks = [
  ["Home", "#/"],
  ["Documentação", "#/docs"],
  ["Playground", "#/playground"],
  ["Download", "#/download"],
];

const exploreLinks = [
  ["Terminal", "#/terminal"],
  ["Biblioteca", "#/biblioteca"],
  ["Roadmap", "#/roadmap"],
  ["Atualizações", "#/atualizacoes"],
  ["Sobre", "#/sobre"],
  ["Suporte", "#/suporte"],
];

function IconSearch() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m21 21-4.35-4.35m2.35-5.65a8 8 0 1 1-16 0 8 8 0 0 1 16 0Z" />
    </svg>
  );
}

function IconSun() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42" />
    </svg>
  );
}

function IconMoon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M20 15.2A8.5 8.5 0 0 1 8.8 4 8.5 8.5 0 1 0 20 15.2Z" />
    </svg>
  );
}

function IconGithub() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48v-1.87c-2.78.6-3.37-1.18-3.37-1.18-.45-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.9 1.53 2.35 1.09 2.92.83.09-.65.35-1.09.64-1.34-2.22-.25-4.56-1.11-4.56-4.95 0-1.09.39-1.98 1.03-2.68-.1-.25-.45-1.27.1-2.64 0 0 .84-.27 2.75 1.02A9.5 9.5 0 0 1 12 6.82a9.5 9.5 0 0 1 2.5.34c1.91-1.3 2.75-1.02 2.75-1.02.55 1.37.2 2.39.1 2.64.64.7 1.03 1.59 1.03 2.68 0 3.85-2.34 4.69-4.57 4.94.36.31.68.92.68 1.86v2.75c0 .27.18.58.69.48A10 10 0 0 0 12 2Z" />
    </svg>
  );
}

function IconChevron({ open }) {
  return (
    <svg className={`nav-chevron ${open ? "is-open" : ""}`} viewBox="0 0 24 24" aria-hidden="true">
      <path d="m7 10 5 5 5-5" />
    </svg>
  );
}

export default function Navbar({ route, theme, onThemeChange }) {
  const [open, setOpen] = useState(false);
  const [exploreOpen, setExploreOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const exploreActive = exploreLinks.some(([, href]) => route === href.slice(1));

  const closeMenu = () => {
    setOpen(false);
    setExploreOpen(false);
  };

  return (
    <>
      <nav className="navbar" aria-label="Navegação principal">
        <a className="brand" href="#/" aria-label="Página inicial da JLScript" onClick={closeMenu}>
          <img src="/favicon-jlscript.png" alt="" />
          <span>JLScript</span>
        </a>

        <button
          className="menu-toggle"
          type="button"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          aria-controls="menu-principal"
          onClick={() => setOpen(!open)}
        >
          <i />
          <i />
          <i />
        </button>

        <div id="menu-principal" className={`nav-links ${open ? "mobile-open" : ""}`}>
          {primaryLinks.map(([label, href]) => (
            <a
              className={route === href.slice(1) ? "active" : ""}
              href={href}
              key={href}
              onClick={closeMenu}
            >
              {label}
            </a>
          ))}

          <div className={`nav-explore ${exploreOpen ? "open" : ""}`}>
            <button
              type="button"
              className={`nav-explore-trigger ${exploreActive ? "active" : ""}`}
              aria-expanded={exploreOpen}
              onClick={() => setExploreOpen(!exploreOpen)}
            >
              Explorar
              <IconChevron open={exploreOpen} />
            </button>

            {exploreOpen && (
              <div className="nav-explore-menu">
                {exploreLinks.map(([label, href]) => (
                  <a
                    className={route === href.slice(1) ? "active" : ""}
                    href={href}
                    key={href}
                    onClick={closeMenu}
                  >
                    <span>{label}</span>
                    <b aria-hidden="true">→</b>
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="nav-actions">
          <button
            className="nav-icon-btn"
            type="button"
            onClick={() => setSearchOpen(true)}
            aria-label="Pesquisar no portal"
            title="Pesquisar"
          >
            <IconSearch />
          </button>

          <button className="navbar-jlai" type="button" onClick={() => setSupportOpen(true)}>
            <img src="/jlai-support.png" alt="" />
            <span>JLAI</span>
          </button>

          <a
            className="nav-icon-btn github-link"
            href="https://github.com/JLScripter/documentacao_JLScripter"
            target="_blank"
            rel="noreferrer"
            aria-label="Documentação pública da JLScript no GitHub"
            title="Documentação no GitHub"
          >
            <IconGithub />
          </a>

          <button
            className="nav-icon-btn"
            onClick={onThemeChange}
            aria-label="Alternar tema"
            title="Alternar tema"
          >
            {theme === "dark" ? <IconSun /> : <IconMoon />}
          </button>
        </div>
      </nav>

      <GlobalSearch open={searchOpen} onClose={() => setSearchOpen(false)} />

      {route !== "/jlai" && (
        <div className="jlai-widget">
          {supportOpen && (
            <section className="jlai-popover" aria-label="Chat rápido da JLAI">
              <header>
                <img src="/jlai-support.png" alt="" />
                <div>
                  <b>JLAI</b>
                  <small>Especialista em JLScript</small>
                </div>
                <button type="button" onClick={() => setSupportOpen(false)} aria-label="Fechar suporte">
                  ×
                </button>
              </header>
              <div className="jlai-popover-body">
                <p>Olá! Sou a JLAI.</p>
                <p>Posso ajudar com:</p>
                <ul>
                  <li>JLScript e sintaxe</li>
                  <li>Código, APIs e bibliotecas</li>
                  <li>Erros e documentação</li>
                </ul>
                <p>Como posso ajudar?</p>
              </div>
              <a className="jlai-popover-input" href="#/jlai">
                Escreva sua dúvida aqui… <span>→</span>
              </a>
            </section>
          )}

          <button
            className="jlai-fab"
            type="button"
            onClick={() => setSupportOpen(!supportOpen)}
            aria-label="Abrir suporte JLAI"
            aria-expanded={supportOpen}
          >
            <img src="/jlai-support.png" alt="" />
            <b>JLAI</b>
            <small>Suporte inteligente</small>
          </button>
        </div>
      )}
    </>
  );
}
