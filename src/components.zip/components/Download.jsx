export default function Download() {
  return (
    <section className="download-callout">
      <div className="download-callout__content">
        <p className="eyebrow">JLSCRIPT 3.2.0</p>
        <h2>Instale, abra o terminal e comece pelo código.</h2>
        <p>A página de downloads reúne os binários Windows fornecidos, hashes de integridade e os comandos para verificar sua instalação.</p>
        <ul>
          <li>CLI <code>jls</code></li>
          <li>Diagnóstico com <code>jls doctor</code></li>
          <li>Documentação pública</li>
        </ul>
        <div className="download-callout__actions">
          <a className="btn" href="#/download">Abrir downloads ↓</a>
          <a className="btn-outline" href="#/docs">Ler documentação</a>
        </div>
      </div>
      <aside className="download-callout__badge" aria-label="Versão atual da linguagem"><span>JLS</span><b>3.2.0</b><small>versão da linguagem</small></aside>
    </section>
  );
}
